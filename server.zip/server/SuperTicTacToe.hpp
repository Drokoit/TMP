#pragma once

#include "BoardGame.hpp"

class SuperTicTacToe : public BoardGame {
public:
    SuperTicTacToe(const Player *p1, const Player *p2) noexcept;
};
