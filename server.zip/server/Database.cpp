#include "Database.hpp"

#include <QSqlQuery>
#include <QSqlError>

#include <stdexcept>

Database *Database::ins = nullptr;

Database::Database() :
    database(QSqlDatabase::addDatabase("QSQLITE"))
{
    this->database.setDatabaseName("superttt.db");

    if (database.open() == false)
        throw std::runtime_error{"Couldn't connect to database!"};

    QSqlQuery q;

    if (!q.exec("CREATE TABLE IF NOT EXISTS users (\n"
                "username TEXT PRIMARY KEY,\n"
                "password TEXT NOT NULL,\n"
                "score INT NOT NULL);"))
    {
        qDebug("Error creating tables!\n%s", q.lastError().text().toStdString().data());
    }
}

Database &Database::instance()
{
    if (ins == nullptr)
        ins = new Database{};

    return *ins;
}

void Database::destroy()
{
    delete ins;
    ins = nullptr;
}

void Database::up_score(const std::string &name)
{
    QSqlQuery q;

    q.prepare("UPDATE users SET score = score + 1 WHERE username = :username");
    q.bindValue(":username", name.data());

    if (!q.exec())
    {
        qDebug("Error incrementing score!");
    }
}

void Database::down_score(const std::string &name)
{
    QSqlQuery q;

    q.prepare("UPDATE users SET score = score - 1 WHERE username = :username");
    q.bindValue(":username", name.data());

    if (!q.exec())
    {
        qDebug("Error decrementing score!");
    }
}

bool Database::login(const std::string &name, const std::string &password)
{
    QSqlQuery q;

    q.prepare("SELECT password FROM users WHERE username = :username");
    q.bindValue(":username", name.data());

    q.exec();
    if (!q.next())
    {
        qDebug("Error logging user in!\n%s", q.lastError().text().toStdString().data());
        return false;
    }

    QString pass = q.value(0).toString();

    return pass.toStdString() == password;
}

bool Database::reg(const std::string &name, const std::string &password)
{
    QSqlQuery q;

    q.prepare("INSERT INTO users (username, password, score) VALUES (:username, :password, 0)");
    q.bindValue(":username", name.data());
    q.bindValue(":password", password.data());

    if (!q.exec()) {
        qDebug("Couldn't create user!");
        return false;
    }

    return true;
}
