#pragma once

#include "BoardGame.hpp"

class TicTacToe : public BoardGame {
public:
    TicTacToe(const Player *p1, const Player *p2) noexcept;
};
