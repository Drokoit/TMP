#pragma once

#include "Game.hpp"

#include "Exception.hpp"

#include <immer/map.hpp>
#include <immer/array.hpp>
#include <memory>

class BoardGame : public Game {
public:
    using Board = immer::map<std::string, immer::array<int>>;

private:
    const std::unique_ptr<const Player> p1;
    const std::unique_ptr<const Player> p2;
    const Board board;
    BoardGame::Board(*const place_func)(const BoardGame::Board&,
                                        const Player&);
    bool(*const end_func)(const immer::array<int>&);
    const bool end;

public:
    std::unique_ptr<const Game> next_move() const override;
    const Player *current_player() const override;
    const Player *winner() const override;

public:
    BoardGame(const Player *p1, const Player *p2,
              BoardGame::Board(*place_func)(const BoardGame::Board&,
                                            const Player&),
              bool(*end_func)(const immer::array<int>&)) noexcept;

private:
    BoardGame(const Player *p1, const Player *p2, const Board &board,
              BoardGame::Board(*place_func)(const BoardGame::Board&,
                                            const Player&),
              bool(*end_func)(const immer::array<int>&),
              bool end) noexcept;
};
