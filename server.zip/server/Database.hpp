#pragma once

#include <QSqlDatabase>

#include <string>

class Database {
    QSqlDatabase database;
    static Database *ins;

    Database();
    ~Database() = default;

public:
    static void destroy();
    static Database &instance();

    void up_score(const std::string &name);
    void down_score(const std::string &name);
    bool login(const std::string &name, const std::string &password);
    bool reg(const std::string &name, const std::string &password);

    Database(const Database &other) = delete;
    Database &operator=(const Database &other) = delete;
};
