#include "IOPlayer.hpp"

IOPlayer::IOPlayer(const std::string &name, int &buffer) noexcept
    : IOPlayer(name, buffer, -1) {}

IOPlayer::IOPlayer(const std::string &name, int &buffer, int move) noexcept
    : name_(name), buffer(buffer), move_(move) {}

std::string IOPlayer::name() const
{
    return this->name_;
}

int IOPlayer::move() const
{
    if (this->buffer == -1)
        this->buffer = this->move_;

    return this->buffer;
}

std::unique_ptr<const Player> IOPlayer::copy() const
{
    return std::unique_ptr<const Player>{
        new IOPlayer{this->name_, this->buffer, this->move_}
    };
}

std::unique_ptr<const Player> IOPlayer::reset() const
{
    return std::unique_ptr<const Player>{
        new IOPlayer{this->name_, this->buffer}
    };
}
