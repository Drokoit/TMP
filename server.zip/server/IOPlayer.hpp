#pragma once

#include "Player.hpp"

class IOPlayer : public Player {
private:
    const std::string &name_;
    int &buffer;
    mutable int move_;

public:
    std::string name() const override;
    int move() const override;
    std::unique_ptr<const Player> copy() const override;
    std::unique_ptr<const Player> reset() const override;

public:
    IOPlayer(const std::string &name, int &buffer) noexcept;
    IOPlayer(const std::string &name, int &buffer, int move) noexcept;
};
