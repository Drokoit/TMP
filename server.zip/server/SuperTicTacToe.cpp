#include "SuperTicTacToe.hpp"

static int map[] = { 0, 0, 0, 1, 1, 1, 2, 2, 2, 0, 0, 0, 1, 1, 1, 2, 2, 2, 0, 0, 0, 1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5, 3, 3, 3, 4, 4, 4, 5, 5, 5, 3, 3, 3, 4, 4, 4, 5, 5, 5, 6, 6, 6, 7, 7, 7, 8, 8, 8, 6, 6, 6, 7, 7, 7, 8, 8, 8, 6, 6, 6, 7, 7, 7, 8, 8, 8 };

static int last_move(const BoardGame::Board &board)
{
    const immer::array<int> *longest;
    size_t longest_size = 0;

    for (const auto &p : board) {
        const immer::array<int> * const arr = &p.second;
        size_t size = arr->size();

        if (size > longest_size) {
            longest = arr;
            longest_size = size;
        }
    }

    return longest->back();
}

static BoardGame::Board place(const BoardGame::Board &board,
                              const Player &player)
{
    const std::string name = player.name();
    const immer::array<int> * const moves = board.find(name);
    const int m = player.move();

    if (m < 0 || m > 8)
        throw BadMove(m, 0, 8);

    return board.set(name, moves ?
                                 moves->push_back(m) :
                 immer::array<int>{std::initializer_list<int>{m}});
}

static bool end(const immer::array<int> &arr)
{
    bool points[9] = { false };

    if (arr.size() >= 9)
        return true;

    for (const int e : arr)
        points[e] = true;

    return
    (points[0] && points[1] && points[2]) ||
    (points[3] && points[4] && points[5]) ||
    (points[6] && points[7] && points[8]) ||
    (points[0] && points[3] && points[6]) ||
    (points[1] && points[4] && points[7]) ||
    (points[2] && points[5] && points[8]) ||
    (points[0] && points[4] && points[8]) ||
    (points[2] && points[4] && points[6]);
}

SuperTicTacToe::SuperTicTacToe(const Player *p1, const Player *p2) noexcept
    : BoardGame(p1, p2, ::place, ::end) {}
