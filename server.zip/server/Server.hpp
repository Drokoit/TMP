#pragma once

#include "Game.hpp"

#include <vector>
#include <functional>
#include <unordered_map>

#include <QObject>
#include <QTcpSocket>
#include <QTcpServer>

class Server : public QObject {
    Q_OBJECT

public:
    struct Game {
        int *buffer;
        std::size_t id;
    };

    struct Player {
        using Ref = std::reference_wrapper<const Player>;

        std::string name;
        std::vector<Ref> challengers;
        std::vector<Ref> invites;
        std::unordered_map<QTcpSocket*, Game> games;
    };

private:
    std::unordered_map<QTcpSocket*, Player> players;
    std::unordered_map<std::string, QTcpSocket*> names;
    std::vector<const ::Game*> games;
    QTcpServer * const tcp_server;

private slots:
    void accept_connection();
    void process_request();
    void drop_connection();

public:
    Server() noexcept;
};
