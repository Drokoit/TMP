#include <QCoreApplication>

#include "Server.hpp"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    const auto s = Server();

    a.exec();
    return 0;
}
