#include <immer/flex_vector.hpp>

immer::flex_vector<int> v{1};

int main() { return 0; }
