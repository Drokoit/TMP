#define IMMER_BENCHMARK_MEMORY_UNSIGNED 1

#include "memory.hpp"

int main() { return main_lin(); }
