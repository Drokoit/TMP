#define IMMER_BENCHMARK_MEMORY_STRING_SHORT 1

#include "memory.hpp"

int main() { return main_lin(); }
