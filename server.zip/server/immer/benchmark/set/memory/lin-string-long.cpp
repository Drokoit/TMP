#define IMMER_BENCHMARK_MEMORY_STRING_LONG 1

#include "memory.hpp"

int main() { return main_lin(); }
