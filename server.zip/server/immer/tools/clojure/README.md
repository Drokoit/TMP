
```
lein run
```
