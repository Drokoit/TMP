
```
# sbt
> test
> test-only org.immer.* -- -verbose
```
