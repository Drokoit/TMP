Reference
=========

These are the interfaces of the various parts of the
``immer::persist`` library.

Policy
------

.. doxygengroup:: Persist-policy
   :project: immer
   :content-only:


API Overview
------------

.. doxygengroup:: persist-api
   :project: immer
   :content-only:


Transform API
---------------

.. doxygengroup:: Persist-transform
   :project: immer
   :content-only:


Exceptions
----------

.. doxygengroup:: Persist-exceptions
   :project: immer
   :content-only:
