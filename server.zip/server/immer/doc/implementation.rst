Implementation overview
=======================

.. image:: https://upload.wikimedia.org/wikipedia/commons/e/e6/%22Work_in_progress%22%2C_animated.gif
   :alt: Work in Progress
   :align: center
