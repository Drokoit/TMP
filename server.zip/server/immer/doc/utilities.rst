.. highlight:: c++

Utilities
=========

The library provides also some types that, while they are not exactly
immutable data-structures, they are very useful when using immutable
data-structures and value-oriented design in practice.

atom
----

.. doxygenclass:: immer::atom
    :members:
    :undoc-members:
