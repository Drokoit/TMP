#pragma once

#include <stdexcept>
#include <string>

class BadMove : public std::exception {
private:
    const std::string message;

public:
    const char *what() const noexcept override;

public:
    BadMove(int move, int min, int max) noexcept;
};
