#pragma once

#include <string>
#include <memory>

struct Player {
    virtual std::string name() const = 0;
    virtual int move() const = 0;

    virtual std::unique_ptr<const Player> copy() const = 0;
    virtual std::unique_ptr<const Player> reset() const = 0;

    virtual ~Player() noexcept = default;
};
