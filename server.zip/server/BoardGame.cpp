#include "BoardGame.hpp"

BoardGame::BoardGame(const Player *p1, const Player *p2, const Board &board,
                     BoardGame::Board(*place_func)(const BoardGame::Board&,
                                                   const Player&),
                     bool(*end_func)(const immer::array<int>&),
                     bool end) noexcept
    : p1(p1), p2(p2), board(board), place_func(place_func), end_func(end_func),
    end(end) {}

BoardGame::BoardGame(const Player *p1, const Player *p2,
                     BoardGame::Board(*place_func)(const BoardGame::Board&,
                                                   const Player&),
                     bool(*end_func)(const immer::array<int>&)) noexcept
    : BoardGame(p1, p2, Board{}, place_func, end_func, false) {}

std::unique_ptr<const Game> BoardGame::next_move() const
{
    if (this->end)
        return nullptr;

    const Board next_board = this->place_func(this->board, *this->p1);
    const bool end = this->end_func(next_board.at(this->p1->name()));

    return std::unique_ptr<const Game>{
        new BoardGame{this->p2->copy().release(),
                      this->p1->reset().release(),
                      next_board,
                      this->place_func, this->end_func,
                      end}
    };
}

const Player *BoardGame::current_player() const
{
    return this->end ? nullptr : this->p1.get();
}

const Player *BoardGame::winner() const
{
    return this->end ? this->p2.get() : nullptr;
}
