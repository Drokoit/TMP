#include "Exception.hpp"

BadMove::BadMove(int move, int min, int max) noexcept
    : message("Moved " + std::to_string(move)
              + ". Legal range is: "
              + std::to_string(min)
              + "-" +
              std::to_string(max)) {}

const char *BadMove::what() const noexcept
{
    return this->message.c_str();
}
