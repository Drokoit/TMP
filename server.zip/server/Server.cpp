#include "Server.hpp"
#include "SuperTicTacToe.hpp"
#include "IOPlayer.hpp"
#include "Database.hpp"

#include <algorithm>

#include <QTcpSocket>
#include <QRandomGenerator>

static void list_players(std::unordered_map<QTcpSocket*, Server::Player> &players,
                         std::unordered_map<std::string, QTcpSocket*> &names,
                         std::vector<const ::Game*> &games,
                         QTcpSocket *socket,
                         const QList<QByteArray> &request)
{
    for (const auto &player : players) {
        socket->write(player.second.name.c_str());
        socket->putChar('\n');
    }

    socket->write("OK:LIST\n");
}

static void reg_user(std::unordered_map<QTcpSocket*, Server::Player> &players,
                     std::unordered_map<std::string, QTcpSocket*> &names,
                     std::vector<const ::Game*> &games,
                     QTcpSocket *socket,
                     const QList<QByteArray> &request)
{
    if (request.size() < 2) {
        socket->write("ERROR:EXPECTED_ARG\n");
        return;
    }

    const std::string password = request[1].toStdString();

    if (password.empty()) {
        socket->write("ERROR:PASSWORD_EMPTY\n");
        return;
    }

    Database &db = Database::instance();

    if (!db.reg(players[socket].name, password)) {
        socket->write("ERROR:REGISTER\n");
        return;
    }

    socket->write("OK:REGISTER\n");
}

static void login_user(std::unordered_map<QTcpSocket*, Server::Player> &players,
                       std::unordered_map<std::string, QTcpSocket*> &names,
                       std::vector<const ::Game*> &games,
                       QTcpSocket *socket,
                       const QList<QByteArray> &request)
{
    if (request.size() < 2) {
        socket->write("ERROR:EXPECTED_ARG\n");
        return;
    }

    const std::string password = request[1].toStdString();

    if (password.empty()) {
        socket->write("ERROR:PASSWORD_EMPTY\n");
        return;
    }

    Database &db = Database::instance();

    // Проверяем наличие пользователя в players
    if (players.find(socket) != players.end()) {
        if (db.login(players[socket].name, password)) {
            socket->write("OK:LOGIN\n");
        } else {
            socket->write("ERROR:INVALID_PASSWORD\n");
        }
    } else {
        socket->write("ERROR:USER_DOES_NOT_EXIST\n");
    }
}


static void assign_name(std::unordered_map<QTcpSocket*, Server::Player> &players,
                        std::unordered_map<std::string, QTcpSocket*> &names,
                        std::vector<const ::Game*> &games,
                        QTcpSocket *socket,
                        const QList<QByteArray> &request)
{
    if (request.size() < 2) {
        socket->write("ERROR:EXPECTED_ARG\n");
        return;
    }

    const std::string name = request[1].toStdString();

    if (name.empty()) {
        socket->write("ERROR:NAME_EMPTY\n");
        return;
    }

    if (names.find(name) != names.cend())
    {
        socket->write("ERROR:ALREADY_EXISTS\n");
        return;
    }

    if (players.find(socket) != players.cend()) {
        names.erase(names.find(players[socket].name));
    }

    names[name] = socket;
    players[socket] = Server::Player{name};
    socket->write("OK:NAME\n");
}

static void invite_player(std::unordered_map<QTcpSocket*, Server::Player> &players,
                          std::unordered_map<std::string, QTcpSocket*> &names,
                          std::vector<const ::Game*> &games,
                          QTcpSocket *socket,
                          const QList<QByteArray> &request)
{
    if (request.size() < 2) {
        socket->write("ERROR:EXPECTED_ARG\n");
        return;
    }

    if (players.find(socket) == players.cend()) {
        socket->write("ERROR:NO_NAME\n");
        return;
    }

    const std::string name = request[1].toStdString();

    if (name.empty()) {
        socket->write("ERROR:NAME_EMPTY\n");
        return;
    }

    if (players[socket].name == name) {
        socket->write("ERROR:SELF\n");
        return;
    }

    if (names.find(name) == names.cend()) {
        socket->write("ERROR:DOES_NOT_EXIST\n");
        return;
    }

    QTcpSocket * const player = names[name];

    std::vector<Server::Player::Ref> &invites = players[socket].invites;
    if (std::find_if(invites.cbegin(), invites.cend(),
                     [&players, &player](const Server::Player::Ref &r){
                         return &r.get() == &players[player];
                     }) != invites.cend())
    {
        socket->write("ERROR:ALREADY_EXISTS\n");
        return;
    }

    std::vector<Server::Player::Ref> &ch = players[socket].challengers;
    if (std::find_if(ch.cbegin(), ch.cend(),
                     [&players, &player](const Server::Player::Ref &r){
                         return &r.get() == &players[player];
                     }) != ch.cend())
    {
        socket->write("ERROR:ALREADY_EXISTS\n");
        return;
    }

    players[player].challengers.push_back(std::cref(players[socket]));
    invites.push_back(std::cref(players[player]));

    player->write(QString("INVITED:%1\n")
                  .arg(players[socket].name.c_str()).toLocal8Bit());
    socket->write("OK:INVITE\n");
}

static void decline_player(std::unordered_map<QTcpSocket*, Server::Player> &players,
                           std::unordered_map<std::string, QTcpSocket*> &names,
                           std::vector<const ::Game*> &games,
                           QTcpSocket *socket,
                           const QList<QByteArray> &request)
{
    if (request.size() < 2) {
        socket->write("ERROR:EXPECTED_ARG\n");
        return;
    }

    const std::string name = request[1].toStdString();

    if (name.empty()) {
        socket->write("ERROR:NAME_EMPTY\n");
        return;
    }

    if (players[socket].name == name) {
        socket->write("ERROR:SELF\n");
        return;
    }

    if (names.find(name) == names.cend()) {
        socket->write("ERROR:DOES_NOT_EXIST\n");
        return;
    }

    QTcpSocket * const player = names[name];

    std::vector<Server::Player::Ref> &ch = players[socket].challengers;
    std::vector<Server::Player::Ref> &in = players[player].invites;
    const auto ch_it =
        std::find_if(ch.cbegin(), ch.cend(),
                     [&players, &player](const Server::Player::Ref &r){
                         return &r.get() == &players[player];
                     });
    const auto in_it =
        std::find_if(in.cbegin(), in.cend(),
                     [&players, &socket](const Server::Player::Ref &r){
                         return &r.get() == &players[socket];
                     });

    if (ch_it != ch.cend() || in_it != in.cend()) {
        ch.erase(ch_it);
        in.erase(in_it);
    } else {
        socket->write("ERROR:DOES_NOT_EXIST\n");
        return;
    }

    player->write(QString("DECLINED:%1\n").arg(players[socket].name.c_str())
                  .toLocal8Bit());
    socket->write("OK:DECLINE\n");
}

static void accept_player(std::unordered_map<QTcpSocket*,
                          Server::Player> &players,
                          std::unordered_map<std::string, QTcpSocket*> &names,
                          std::vector<const ::Game*> &games,
                          QTcpSocket *socket,
                          const QList<QByteArray> &request)
{
    if (request.size() < 2) {
        socket->write("ERROR:EXPECTED_ARG\n");
        return;
    }

    const std::string name = request[1].toStdString();

    if (name.empty()) {
        socket->write("ERROR:NAME_EMPTY\n");
        return;
    }

    if (players[socket].name == name) {
        socket->write("ERROR:SELF\n");
        return;
    }

    if (names.find(name) == names.cend()) {
        socket->write("ERROR:DOES_NOT_EXIST\n");
        return;
    }

    QTcpSocket * const player = names[name];

    std::vector<Server::Player::Ref> &ch = players[socket].challengers;
    std::vector<Server::Player::Ref> &in = players[player].invites;
    const auto ch_it =
        std::find_if(ch.cbegin(), ch.cend(),
                     [&players, &player](const Server::Player::Ref &r){
                         return &r.get() == &players[player];
                     });
    const auto in_it =
        std::find_if(in.cbegin(), in.cend(),
                     [&players, &socket](const Server::Player::Ref &r){
                         return &r.get() == &players[socket];
                     });

    if (ch_it != ch.cend() || in_it != in.cend()) {
        ch.erase(ch_it);
        in.erase(in_it);
    } else {
        socket->write("ERROR:DOES_NOT_EXIST\n");
        return;
    }

    if (players[socket].games.find(player) != players[socket].games.cend()) {
        socket->write("ERROR:ALREADY_EXISTS\n");
    }

    players[socket].games[player] = Server::Game{
        new int{}, games.size()
    };
    players[player].games[socket] = Server::Game{
        new int{}, games.size()
    };
    QTcpSocket * const p1 = QRandomGenerator::system()->bounded(2) ?
                            socket :
                            player;
    QTcpSocket * const p2 = p1 == socket ? player : socket;

    games.push_back(new SuperTicTacToe{
                    new IOPlayer{
                        players[p1].name,
                        *players[p1].games[p2].buffer
                    },
                    new IOPlayer{
                        players[p2].name,
                        *players[p2].games[p1].buffer
                    }
                 });

    player->write(QString("ACCEPTED:%1:%2\n").arg(players[socket].name.c_str(),
                                                  players[p1].name.c_str())
                  .toLocal8Bit());
    socket->write(QString("OK:ACCEPT:%1\n").arg(players[p1].name.c_str())
                  .toLocal8Bit());
}

static void make_move(std::unordered_map<QTcpSocket*,
                      Server::Player> &players,
                      std::unordered_map<std::string, QTcpSocket*> &names,
                      std::vector<const ::Game*> &games,
                      QTcpSocket *socket,
                      const QList<QByteArray> &request)
{
    if (request.size() < 3) {
        socket->write("ERROR:EXPECTED_ARG\n");
        return;
    }

    const std::string name = request[1].toStdString();
    bool convert_ok;
    const int move = request[2].toInt(&convert_ok);

    if (convert_ok == false) {
        socket->write("ERROR:BAD_MOVE\n");
        return;
    }

    if (name.empty()) {
        socket->write("ERROR:NAME_EMPTY\n");
        return;
    }

    if (players[socket].name == name) {
        socket->write("ERROR:SELF\n");
        return;
    }

    if (names.find(name) == names.cend()) {
        socket->write("ERROR:DOES_NOT_EXIST\n");
        return;
    }

    QTcpSocket * const player = names[name];

    if (players[socket].games.find(player) == players[socket].games.cend()) {
        socket->write("ERROR:DOES_NOT_EXIST\n");
        return;
    }

    const size_t id = players[socket].games[player].id;
    int * const buffer = players[socket].games[player].buffer;
    const Game * const old_game = games[id];
    const Player * const current = old_game->current_player();
    if (current->name() != players[socket].name) {
        socket->write("ERROR:NOT_ALLOWED\n");
        return;
    }

    *buffer = move;

    try {
        games[id] = games[id]->next_move().release();
    } catch (const BadMove &e) {
        socket->write("ERROR:BAD_MOVE\n");
        return;
    }
    if (games[id]->current_player() == nullptr) {
        const Player * const winner = games[id]->winner();
        if (winner) {
            Database &db = Database::instance();
            socket->write(QString("WINNER:%1\n").arg(winner->name().c_str())
                          .toLocal8Bit());
            player->write(QString("WINNER:%1:%2\n").arg(players[socket].name.c_str(),
                                                        winner->name().c_str())
                          .toLocal8Bit());
            db.up_score(winner->name());
            db.down_score(players[player].name);
        } else {
            socket->write(QString("TIE:%1\n").arg(players[player].name.c_str())
                          .toLocal8Bit());
            player->write(QString("TIE:%1\n").arg(players[socket].name.c_str())
                          .toLocal8Bit());
        }
        delete players[socket].games[player].buffer;
        players[socket].games.erase(players[socket].games.find(player));
        players[player].games.erase(players[player].games.find(socket));
        games.erase(games.begin() + id);
        return;
    }
    socket->write("OK:MOVE\n");
    player->write(QString("MOVED:%1:%2\n")
                  .arg(current->name().c_str(),
                       std::to_string(current->move()).c_str())
                  .toLocal8Bit());

    delete old_game;
}

Server::Server() noexcept : tcp_server(new QTcpServer(this))
{
    connect(this->tcp_server, &QTcpServer::newConnection,
            this, &Server::accept_connection);
    this->tcp_server->listen(QHostAddress::LocalHost, 4598);

    qDebug("Server listening on %s:%u",
           this->tcp_server->serverAddress()
             .toString()
             .toLocal8Bit()
             .constData(),
           this->tcp_server->serverPort());
}

void Server::accept_connection()
{
    QTcpSocket *sock = this->tcp_server->nextPendingConnection();
    qDebug("Accepted connection: %s:%u",
           sock->peerAddress()
             .toString()
             .toLocal8Bit()
             .constData(),
           sock->peerPort());

    if (sock == nullptr)
        return;

    sock->connect(sock, &QTcpSocket::readyRead, this, &Server::process_request);
    sock->connect(sock, &QTcpSocket::disconnected,
                  this, &Server::drop_connection);
}

void Server::process_request()
{
    QTcpSocket *sock = qobject_cast<QTcpSocket*>(sender());

    const QByteArray request_line = sock->readLine().trimmed();
    if (request_line.isEmpty()) {
        sock->write("ERROR:EMPTY_REQUEST\n");
        return;
    }

    const QList<QByteArray> request = request_line.split(':');
    const QByteArray cmd = request[0];

    if (cmd == "NAME") {
        assign_name(this->players, this->names, this->games, sock, request);
    } else if (cmd == "LIST") {
        list_players(this->players, this->names, this->games, sock, request);
    } else if (cmd == "INVITE") {
        invite_player(this->players, this->names, this->games, sock, request);
    } else if (cmd == "DECLINE") {
        decline_player(this->players, this->names, this->games, sock, request);
    } else if (cmd == "ACCEPT") {
        accept_player(this->players, this->names, this->games, sock, request);
    } else if (cmd == "MOVE") {
        make_move(this->players, this->names, this->games, sock, request);
    } else if (cmd == "REGISTER") {
        reg_user(this->players, this->names, this->games, sock, request);
    } else if (cmd == "LOGIN") {
        login_user(this->players, this->names, this->games, sock, request);
    } else {
        sock->write("ERROR:BAD_REQUEST\n");
    }
}

void Server::drop_connection()
{
    QTcpSocket *sock = qobject_cast<QTcpSocket*>(sender());

    qDebug("Dropped connection: %s:%u",
           sock->peerAddress()
             .toString()
             .toLocal8Bit()
             .constData(),
           sock->peerPort());
}
