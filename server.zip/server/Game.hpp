#pragma once

#include <memory>

#include "Player.hpp"

struct Game {
    virtual std::unique_ptr<const Game> next_move() const = 0;
    virtual const Player *current_player() const = 0;
    virtual const Player *winner() const = 0;

    virtual ~Game() noexcept = default;
};
