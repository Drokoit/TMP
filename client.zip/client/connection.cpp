#include "connection.h"

Connection::Connection(QObject *parent)
    : QObject{parent}
    , sock(new QTcpSocket(this))
{
    this->sock->connectToHost("127.0.0.1", 4598);

    this->connect(this->sock, &QTcpSocket::readyRead, this, &Connection::onReadyRead);
}

void Connection::onReadyRead()
{
    QTcpSocket *server = qobject_cast<QTcpSocket*>(sender());

    const QByteArray line = server->readLine().trimmed();
    if (line.isEmpty()) {
        qDebug("Received empty line!");
        return;
    }

    const QList<QByteArray> content = line.split(':');

    emit this->response(content);
}

void Connection::sendRequest(const QList<QByteArray> &content)
{
    auto res = content.join(':');
    res.append('\n');

    this->sock->write(res);
}
