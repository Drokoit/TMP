#include "register.h"
#include "ui_register.h"

#include <QDialogButtonBox>

Register::Register(Connection *conn, QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Register)
    , conn(conn)
{
    ui->setupUi(this);

    this->connect(this->ui->buttonBox, &QDialogButtonBox::accepted, this, &Register::onDataReceived);
}

Register::~Register()
{
    delete ui;
}

void Register::onDataReceived()
{
    QString username = this->ui->nameEdit->text();
    QString password = this->ui->passwordEdit->text();

    if (username.isEmpty() or password.isEmpty()) {
        return;
    }

    QList<QByteArray> r;

    r.append("NAME");
    r.append(username.toUtf8());

    this->conn->sendRequest(r);
    r[0] = "REGISTER";
    r[1] = password.toUtf8();
    this->conn->sendRequest(r);
    emit this->usernameChanged(username);
}
