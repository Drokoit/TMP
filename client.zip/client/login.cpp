#include "login.h"
#include "ui_login.h"

#include <QDialogButtonBox>

Login::Login(Connection *conn, QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Login)
    , conn(conn)
{
    ui->setupUi(this);

    this->connect(this->ui->buttonBox, &QDialogButtonBox::accepted, this, &Login::onDataReceived);
}

Login::~Login()
{
    delete ui;
}

void Login::onDataReceived()
{
    QString username = this->ui->nameEdit->text();
    QString password = this->ui->passwordEdit->text();

    if (username.isEmpty() or password.isEmpty()) {
        return;
    }

    QList<QByteArray> r;

    r.append("NAME");
    r.append(username.toUtf8());

    this->conn->sendRequest(r);
    r[0] = "LOGIN";
    r[1] = password.toUtf8();
    this->conn->sendRequest(r);
    emit this->usernameChanged(username);
}
