#ifndef CONNECTION_H
#define CONNECTION_H

#include <QObject>
#include <QList>
#include <QString>
#include <QTcpSocket>

class Connection : public QObject
{
    Q_OBJECT
public:
    explicit Connection(QObject *parent = nullptr);

    void sendRequest(const QList<QByteArray> &content);

signals:
    void response(const QList<QByteArray> &content);

private slots:
    void onReadyRead();

private:
    QTcpSocket *sock;
};

#endif // CONNECTION_H
