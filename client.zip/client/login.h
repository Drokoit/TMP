#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include <string>

#include "connection.h"

namespace Ui {
class Login;
}

class Login : public QDialog
{
    Q_OBJECT

public:
    explicit Login(Connection *conn, QWidget *parent = nullptr);
    ~Login();

private slots:
    void onDataReceived();

signals:
    void usernameChanged(const QString &username);

private:
    Ui::Login *ui;
    Connection *conn;
};

#endif // LOGIN_H
