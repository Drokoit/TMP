#include "game.h"
#include "./ui_game.h"

#include "login.h"
#include "register.h"
#include <QMessageBox>

Game::Game(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::Game)
    , conn(new Connection(this))
{
    ui->setupUi(this);

    this->ui->loginStatus->setText("Welcome! You aren't logged in!");
    this->ui->loginStatus->adjustSize();

    this->connect(this->conn, &Connection::response, this, &Game::onResponse);
    this->connect(this->ui->registerButton, &QPushButton::clicked, this, &Game::onRegisterClick);
    this->connect(this->ui->loginButton, &QPushButton::clicked, this, &Game::onLoginClick);
}

void Game::onResponse(const QList<QByteArray> &content)
{
    if (content.isEmpty())
        return;

    if (content[0] == "ERROR") {
        qDebug("%s", content[1].toStdString().data());
        if (content[1] == "LOGIN") {
            QMessageBox::warning(this, "Login", "Login failed.");
        }
    } else if (content[0] == "OK") {
        if (content[1] == "LOGIN") {
            QMessageBox::information(this, "Login", "Login successful.");
        } else if (content[1] == "REGISTER") {
            QMessageBox::information(this, "Register", "Register successful.");
            this->ui->loginStatus->setText(QString("Logged in as: %1").arg(this->username.data()));
        }
    }
}

Game::~Game()
{
    delete ui;
}

void Game::onUsernameChanged(const QString &username)
{
    this->username = username.toStdString();
}

void Game::onLoginClick()
{
    Login *login = new Login(this->conn, this);
    this->connect(login, &Login::usernameChanged, this, &Game::onUsernameChanged);

    login->show();
}

void Game::onRegisterClick()
{
    Register *reg = new Register(this->conn, this);
    this->connect(reg, &Register::usernameChanged, this, &Game::onUsernameChanged);

    reg->show();
}
