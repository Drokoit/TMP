#ifndef GAME_H
#define GAME_H

#include <QMainWindow>

#include <string>
#include "connection.h"

QT_BEGIN_NAMESPACE
namespace Ui {
class Game;
}
QT_END_NAMESPACE

class Game : public QMainWindow
{
    Q_OBJECT

public:
    Game(QWidget *parent = nullptr);
    ~Game();

private slots:
    void onResponse(const QList<QByteArray> &content);
    void onLoginClick();
    void onUsernameChanged(const QString &username);
    void onRegisterClick();

private:
    Ui::Game *ui;
    Connection *conn;
    std::string username;
};
#endif // GAME_H
