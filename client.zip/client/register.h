#ifndef REGISTER_H
#define REGISTER_H

#include <QDialog>
#include <string>

#include "connection.h"

namespace Ui {
class Register;
}

class Register : public QDialog
{
    Q_OBJECT

public:
    explicit Register(Connection *conn, QWidget *parent = nullptr);
    ~Register();

private slots:
    void onDataReceived();

signals:
    void usernameChanged(const QString &username);

private:
    Ui::Register *ui;
    Connection *conn;
};

#endif // REGISTER_H
